#ifndef KEYPAD_H
#define KEYPAD_H

void getKey(void);
void convertToIntegers(void);
void split_numbers(void);

#endif
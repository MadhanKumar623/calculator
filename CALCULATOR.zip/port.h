#ifndef PORT_H
#define PORT_H

void delay1(int);
void init_port(void);
void set_port(void);

#endif
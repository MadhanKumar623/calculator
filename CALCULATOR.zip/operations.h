#ifndef OPERATIONS_H
#define OPERATIONS_H

long power(char,char);
void calculate(void);

#endif